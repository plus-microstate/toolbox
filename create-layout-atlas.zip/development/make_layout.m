clear, clc, close all

% Add fieldtrip to path - change this to your fieldtrip path
addpath /cubric/scratch/saplt6/fieldtrip-20221121 ; ft_defaults ;

% Load atlas in Fieldtrip format
% This is the AAL atlas from Fieldtrip, just with subcortical regions and
% cerebellum removed, keeping only the 78 cortical regions. You can replace
% this with any atlas in Fieldtrip format.
load('aal78')

% Convert atlas to scattered points
ind = find(atl.tissue>0) ; 
p = [] ; 
[p(:,1),p(:,2),p(:,3)] = ind2sub(size(atl.tissue),ind) ; 
p(:,4) = 1 ;     
p = atl.transform*p' ; 
p = p(1:3,:)' ; 

atl1 = [] ; 
atl1.pos = p ; 
atl1.unit = atl.unit ; 
atl1.tissue = atl.tissue(ind) ; 
atl1.tissuelabel = atl.tissuelabel ; 
atl1.coordsys = atl.coordsys ; 

% Load in the mesh used for interpolation
load('midmesh')

% interpolate atlas onto mesh
cfg = [] ; 
cfg.parameter = 'tissue' ; 
cfg.method = 'nearest' ; 
interp = ft_sourceinterpolate(cfg,atl1,mesh) ; 

% make layout
lay = [] ; 

for i = 1:length(atl.tissuelabel)
    
    ind = find(atl1.tissue==i) ; 
    lay.centroid(i,:) = mean(p(ind,:)) ; 
end

lay.tissue = interp.tissue ; 
lay.tissuelabel = atl.tissuelabel ; 

% save some memory
lay.centroid = single(lay.centroid) ; 
lay.tissue = uint8(lay.tissue) ; 

save('aal_newlayout','-struct','lay')